﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPR321Project.Controllers
{
    class ThicknessController : IDisposable
    {
        public ThicknessController()
        {

        }

        public void Dispose()
        {
            //throw new NotImplementedException();
        }
    }
}
