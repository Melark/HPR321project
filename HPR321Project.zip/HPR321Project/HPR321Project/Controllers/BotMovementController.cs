﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPR321Project.Controllers
{
    class BotMovementController : IDisposable
    {
        public BotMovementController()
        {

        }

        public void Dispose()
        {
            //throw new NotImplementedException();
        }
    }
}
